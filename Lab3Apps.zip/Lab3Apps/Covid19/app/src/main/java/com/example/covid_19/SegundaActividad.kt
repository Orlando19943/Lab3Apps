package com.example.covid_19

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import com.example.covid_19.databinding.ActivitySegundaActividad2Binding
class SegundaActividad : AppCompatActivity() {
    private lateinit var binding : ActivitySegundaActividad2Binding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_segunda_actividad2)
        val objetoIntent: Intent = intent
        var titulo = objetoIntent.getStringExtra("Titulo")
        var subtitulo = objetoIntent.getStringExtra("Subtitulo")
        var descripcion = objetoIntent.getStringExtra("Descripcion")
        binding.tituloView.text = titulo
        binding.subtituloView.text = subtitulo
        binding.descripcionView.text = descripcion
        binding.buttonComentar.setOnClickListener{
            var intent = Intent (this,MainActivity::class.java)
            Toast.makeText(this, binding.comentarioText.text, Toast.LENGTH_SHORT).show()
            startActivity(intent)
        }
    }

}
