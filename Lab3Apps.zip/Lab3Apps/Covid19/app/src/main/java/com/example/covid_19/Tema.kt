package com.example.covid_19

data class Tema (var titulo: String = "", var subtitulo: String = "", var descripcion: String = "")