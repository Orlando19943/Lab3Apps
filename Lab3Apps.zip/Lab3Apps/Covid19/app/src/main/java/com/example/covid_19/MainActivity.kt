package com.example.covid_19

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethod
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.databinding.DataBindingUtil
import com.example.covid_19.databinding.ActivityMainBinding
import kotlinx.android.synthetic.main.activity_main.*

@Suppress("DEPRECATION")
class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val Virus : Tema = Tema ("COVID-19","Virus","El Corona virus o COVID-19, es una enfermedad que surgió el 2019 en China. Es una enfermedad que ataca a las vias respiratorias. Algunas formas de contagiarse es por medio del contacto del virus con los ojos, la nariz y  la boca.")
    private val Sintomas : Tema = Tema ("COVID-19","Sintomas","Algunos sintomas son: fiebre, tos, problemas respiratorios. Si presenta algunos de estos sintomas, porfavor, visite un médico.")
    private val Indicaciones : Tema = Tema ("COVID-19","Indicaciones","Como primera acción que deberia tomar es la de visitar un médico para saber si de verdad se encuentra enfermo. De resultar enfermo, procure permanecer lejos de la población y de ser tratado por médicos.")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        var contador = 0
        // set on-click listener
        binding.imageButton.setOnClickListener {
            if (contador == 0){
                addNickName(it)
                contador++
            }else if (contador == 1){
                addNickName2(it)
                contador--
            }

        }
        binding.buttonVirus.setOnClickListener{
            var intent = Intent (this,SegundaActividad::class.java)
            intent.putExtra("Titulo", Virus.titulo.toString())
            intent.putExtra("Subtitulo", Virus.subtitulo.toString())
            intent.putExtra("Descripcion", Virus.descripcion.toString())
            startActivity(intent)
        }
        binding.buttonSintomas.setOnClickListener{
            var intent = Intent (this,SegundaActividad::class.java)
            intent.putExtra("Titulo", Sintomas.titulo.toString())
            intent.putExtra("Subtitulo", Sintomas.subtitulo.toString())
            intent.putExtra("Descripcion", Sintomas.descripcion.toString())
            startActivity(intent)
        }
        binding.buttonIndicaciones.setOnClickListener{
            var intent = Intent (this,SegundaActividad::class.java)
            intent.putExtra("Titulo", Indicaciones.titulo)
            intent.putExtra("Subtitulo", Indicaciones.subtitulo)
            intent.putExtra("Descripcion", Indicaciones.descripcion)
            startActivity(intent)
        }


    }
    private fun addNickName (view: View){
        var editText = binding.nombreText
        val nicknameTextView = binding.textNombre
        var editText2 = binding.edadText
        val nicknameTextView2 = binding.textEdad
        val textoView = binding.mensajeView
        nicknameTextView.text = editText.text
        nicknameTextView2.text = editText2.text
        var edad = -2
        if (edadText.text.toString().isNotEmpty()){
            edad = edadText.text.toString().toInt()
        }
        val mensaje = when (edad) {
            in 65..111 -> "Las probabilidades de que contraiga la enfermedad son altas, recomendamos que se cuide"
            in 0..3 -> "Las probabilidades de que contraiga la enfermedad son altas, recomendamos que se cuide"
            in 4..64 -> "Las probabilidades de que contraiga la enfermedad son bajas, pero recomendamos que sea cuidadoso a la hora de salir a la calle"
            in 112 ..Int.MAX_VALUE -> "Ingrese su verdadera edad"
            in Int.MIN_VALUE..-1 -> "Ingrese su verdadera edad"
            else -> "Ingrese su verdadera edad"
        }
        textoView.text = "Hola ${editText.text}, $mensaje"
        textoView.visibility = View.VISIBLE
        editText.visibility = View.INVISIBLE
        nicknameTextView.visibility = View.VISIBLE
        editText2.visibility = View.INVISIBLE
        nicknameTextView2.visibility = View.VISIBLE
        //Escondiendo la entrada de texto
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(view.windowToken, 0)
    }
    private fun addNickName2 (view: View){
        var editText = binding.nombreText
        val nicknameTextView = binding.textNombre
        var editText2 = binding.edadText
        val nicknameTextView2 = binding.textEdad
        val textoView = binding.mensajeView
        nicknameTextView.text = editText.text
        nicknameTextView2.text = editText2.text
        editText.visibility = View.VISIBLE
        textoView.visibility = View.INVISIBLE
        nicknameTextView.visibility = View.INVISIBLE
        editText2.visibility = View.VISIBLE
        nicknameTextView2.visibility = View.INVISIBLE
        //Escondiendo la entrada de texto
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(view.windowToken, 0)
    }
}
